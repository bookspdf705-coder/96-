# 96

A two-page site for keeping the photos from your years together — anyone with
the link can add a photo or browse the wall. No accounts, no gatekeeping.

- **Home** — drop in photos (with an optional name and caption)
- **The Wall** — everything anyone has added, newest first, in a masonry
  gallery with a full-screen viewer
- Glassmorphism nav bar pinned to the top, with a light/dark toggle on the
  right
- Built with Next.js (App Router) + Tailwind, storage via **Netlify Blobs**

## 1. Run it locally

```bash
npm install
npm run dev
```

Open http://localhost:3000. Browsing works right away — uploading won't,
since Netlify Blobs needs to run inside a Netlify context. See "Testing
uploads locally" below if you want that working on your machine too.

## 2. Deploy to Netlify

**Option A — through the Netlify dashboard (no CLI needed):**
1. Push this folder to a GitHub repo.
2. Go to [app.netlify.com](https://app.netlify.com) → **Add new site** →
   **Import an existing project** → pick the repo.
3. Netlify reads `netlify.toml` automatically and picks the right build
   settings — just click **Deploy**.

**Option B — from the command line:**
```bash
npm i -g netlify-cli
netlify login
netlify init      # links this folder to a new or existing Netlify site
netlify deploy --prod
```

That's it — no separate storage setup step. Netlify Blobs is built into
every Netlify site, so uploads work as soon as the deploy finishes.

## Testing uploads locally

`npm run dev` alone can't reach Netlify Blobs, since that storage only
exists inside a Netlify site's runtime. To test uploads before deploying:

```bash
npm i -g netlify-cli
netlify link       # connect this folder to your Netlify site
netlify dev         # runs the app locally, with Blobs storage working
```

## How it's structured

```
app/
  page.tsx                        Home — hero + upload
  wall/page.tsx                    The Wall — gallery
  api/photos/route.ts              GET (list) / POST (upload) a photo
  api/photos/image/[...key]/       Streams a photo's bytes back out of
    route.ts                       Blobs storage with the right content type
  layout.tsx                       Shell: theme provider + navbar
components/
  Navbar.tsx                       Glass nav, Home / The Wall, theme toggle
  ThemeToggle.tsx
  UploadZone.tsx                   Drag-and-drop uploader
  PhotoGrid.tsx                    Masonry gallery + skeleton/empty states
  Lightbox.tsx                     Full-screen photo viewer
lib/
  theme-provider.tsx               next-themes wrapper (class-based dark mode)
netlify.toml                       Build command + Next.js runtime plugin
```

Photo metadata (who added it, its caption, when) lives alongside the images
in a single `manifest.json` inside the same Blobs store — there's nothing
else to provision.

## Notes

- Since anyone with the link can upload, there's no moderation built in. If
  this matters to you, the simplest guard is Netlify's password protection
  (Site configuration → Visitor access) or adding a shared passphrase gate —
  ask if you'd like that added.
- Uploads are capped at 15MB per photo and images only.
- Design language: SF Pro–style system type, soft glass surfaces, a warm
  gold accent standing in for a class ring / yearbook gold foil, dark mode
  as the default (matching how apple.com opens on most pages now).
