import { PhotoGrid } from "@/components/PhotoGrid";

export default function WallPage() {
  return (
    <div className="mx-auto max-w-6xl px-5 pb-32 pt-6 sm:px-8 sm:pt-10">
      <div className="mx-auto mb-14 max-w-2xl text-center">
        <h1 className="animate-fade-up font-display text-[36px] font-semibold leading-tight tracking-tighter text-ink dark:text-white sm:text-[48px]">
          The Wall
        </h1>
        <p
          className="mt-3 animate-fade-up text-[16px] leading-relaxed text-smoke sm:text-[17px]"
          style={{ animationDelay: "80ms" }}
        >
          Every photo, from everyone. Tap any of them to look closer.
        </p>
      </div>

      <PhotoGrid />
    </div>
  );
}
