import { getStore } from "@netlify/blobs";
import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type PhotoEntry = {
  id: string;
  url: string;
  key: string;
  name: string | null;
  caption: string | null;
  uploadedAt: string;
};

const MANIFEST_KEY = "manifest.json";
const MAX_BYTES = 15 * 1024 * 1024;

const EXT_CONTENT_TYPES: Record<string, string> = {
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  gif: "image/gif",
  webp: "image/webp",
  heic: "image/heic",
  heif: "image/heif",
  bmp: "image/bmp",
  avif: "image/avif",
  tif: "image/tiff",
  tiff: "image/tiff",
};

function photosStore() {
  // "strong" consistency so a photo we just wrote shows up immediately
  // in the very next read of the manifest (Netlify Blobs is eventually
  // consistent by default).
  return getStore({ name: "photos", consistency: "strong" });
}

async function readManifest(): Promise<PhotoEntry[]> {
  try {
    const store = photosStore();
    const data = await store.get(MANIFEST_KEY, { type: "json" });
    return Array.isArray(data) ? (data as PhotoEntry[]) : [];
  } catch (err) {
    console.error("[96] Failed to read manifest.json from Netlify Blobs:", err);
    return [];
  }
}

async function writeManifest(entries: PhotoEntry[]) {
  try {
    const store = photosStore();
    await store.setJSON(MANIFEST_KEY, entries);
  } catch (err) {
    console.error("[96] Failed to write manifest.json to Netlify Blobs:", err);
    throw err;
  }
}

export async function GET() {
  const entries = await readManifest();
  entries.sort(
    (a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
  );
  return NextResponse.json({ photos: entries });
}

export async function POST(request: Request) {
  let formData: FormData;
  try {
    formData = await request.formData();
  } catch {
    return NextResponse.json({ error: "That upload couldn't be read." }, { status: 400 });
  }

  const file = formData.get("file");
  const name = formData.get("name");
  const caption = formData.get("caption");

  if (!(file instanceof File) || file.size === 0) {
    return NextResponse.json({ error: "Choose a photo to add." }, { status: 400 });
  }
  const looksLikeImage =
    file.type.startsWith("image/") ||
    /\.(jpe?g|png|gif|webp|heic|heif|bmp|avif|tiff?)$/i.test(file.name);
  if (!looksLikeImage) {
    return NextResponse.json(
      { error: "Only image files can be added to the wall." },
      { status: 400 }
    );
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json({ error: "Photos must be under 15MB." }, { status: 400 });
  }

  let entry: PhotoEntry;
  try {
    const id = randomUUID();
    const extMatch = file.name.match(/\.([a-zA-Z0-9]+)$/);
    const ext = extMatch ? extMatch[1].toLowerCase() : "jpg";
    const key = `photos/${id}.${ext}`;
    const contentType = file.type || EXT_CONTENT_TYPES[ext] || "application/octet-stream";

    const store = photosStore();
    const bytes = await file.arrayBuffer();
    await store.set(key, bytes, { metadata: { contentType } });

    entry = {
      id,
      url: `/api/photos/image/${key}`,
      key,
      name: typeof name === "string" && name.trim() ? name.trim().slice(0, 60) : null,
      caption:
        typeof caption === "string" && caption.trim()
          ? caption.trim().slice(0, 200)
          : null,
      uploadedAt: new Date().toISOString(),
    };
  } catch (err) {
    console.error("[96] Failed to upload photo to Netlify Blobs:", err);
    return NextResponse.json(
      {
        error:
          "Storage isn't connected yet. Make sure this site has a Netlify Blobs-enabled deploy and try again.",
      },
      { status: 500 }
    );
  }

  try {
    const entries = await readManifest();
    entries.push(entry);
    await writeManifest(entries);
  } catch (err) {
    console.error("[96] Photo was stored but the manifest update failed:", err);
    return NextResponse.json(
      { error: "The photo saved, but couldn't be listed. Try refreshing The Wall." },
      { status: 500 }
    );
  }

  return NextResponse.json({ photo: entry }, { status: 201 });
}
