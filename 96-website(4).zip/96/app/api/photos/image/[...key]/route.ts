import { getStore } from "@netlify/blobs";
import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: { key: string[] } }
) {
  const key = params.key.join("/");

  try {
    const store = getStore({ name: "photos", consistency: "strong" });
    const result = await store.getWithMetadata(key, { type: "arrayBuffer" });

    if (!result) {
      return new NextResponse("Not found", { status: 404 });
    }

    const contentType =
      (result.metadata?.contentType as string | undefined) || "application/octet-stream";

    return new NextResponse(result.data, {
      headers: {
        "Content-Type": contentType,
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  } catch (err) {
    console.error(`[96] Failed to read photo "${key}" from Netlify Blobs:`, err);
    return new NextResponse("Not found", { status: 404 });
  }
}
