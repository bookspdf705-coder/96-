"use client";

import { useEffect } from "react";

export type Photo = {
  id: string;
  url: string;
  name: string | null;
  caption: string | null;
  uploadedAt: string;
};

export function Lightbox({
  photo,
  onClose,
}: {
  photo: Photo;
  onClose: () => void;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  const date = new Date(photo.uploadedAt).toLocaleDateString(undefined, {
    month: "long",
    day: "numeric",
    year: "numeric",
  });

  return (
    <div
      className="fixed inset-0 z-[100] flex animate-fade-in items-center justify-center bg-black/85 p-4 backdrop-blur-md"
      onClick={onClose}
    >
      <button
        onClick={onClose}
        aria-label="Close"
        className="absolute right-5 top-5 flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
          <path
            d="M6 6l12 12M18 6L6 18"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      </button>

      <div
        className="flex max-h-[88vh] w-full max-w-4xl flex-col items-center"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex max-h-[72vh] w-full items-center justify-center overflow-hidden rounded-2xl">
          <img
            src={photo.url}
            alt={photo.caption || "Memory"}
            className="max-h-[72vh] w-auto max-w-full rounded-2xl object-contain"
          />
        </div>
        {(photo.caption || photo.name) && (
          <div className="mt-5 max-w-xl text-center">
            {photo.caption && (
              <p className="font-display text-[19px] text-white text-balance">
                {photo.caption}
              </p>
            )}
            <p className="mt-2 text-[13px] text-white/50">
              {photo.name ? `${photo.name} · ` : ""}
              {date}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
