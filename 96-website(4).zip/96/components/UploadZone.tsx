"use client";

import { useCallback, useRef, useState } from "react";
import Image from "next/image";

type QueueItem = {
  key: string;
  file: File;
  preview: string;
  status: "pending" | "uploading" | "done" | "error";
  error?: string;
};

export function UploadZone() {
  const [items, setItems] = useState<QueueItem[]>([]);
  const [dragging, setDragging] = useState(false);
  const [name, setName] = useState("");
  const [caption, setCaption] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const addFiles = useCallback((fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    const isImage = (f: File) =>
      f.type.startsWith("image/") || /\.(jpe?g|png|gif|webp|heic|heif|bmp|avif|tiff?)$/i.test(f.name);
    const images = Array.from(fileList).filter(isImage);
    if (images.length === 0) return;
    setItems((prev) => [
      ...prev,
      ...images.map((file) => ({
        key: `${file.name}-${file.size}-${Math.random().toString(36).slice(2)}`,
        file,
        preview: URL.createObjectURL(file),
        status: "pending" as const,
      })),
    ]);
  }, []);

  const upload = useCallback(
    async (item: QueueItem) => {
      setItems((prev) =>
        prev.map((i) => (i.key === item.key ? { ...i, status: "uploading" } : i))
      );
      try {
        const body = new FormData();
        body.append("file", item.file);
        if (name.trim()) body.append("name", name.trim());
        if (caption.trim()) body.append("caption", caption.trim());
        const res = await fetch("/api/photos", { method: "POST", body });
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          throw new Error(data.error || "That photo couldn't be added.");
        }
        setItems((prev) =>
          prev.map((i) => (i.key === item.key ? { ...i, status: "done" } : i))
        );
      } catch (err) {
        setItems((prev) =>
          prev.map((i) =>
            i.key === item.key
              ? { ...i, status: "error", error: (err as Error).message }
              : i
          )
        );
      }
    },
    [caption, name]
  );

  const uploadAll = useCallback(() => {
    items.filter((i) => i.status === "pending" || i.status === "error").forEach(upload);
  }, [items, upload]);

  const removeItem = (key: string) => {
    setItems((prev) => prev.filter((i) => i.key !== key));
  };

  const pendingCount = items.filter((i) => i.status === "pending" || i.status === "error").length;

  return (
    <div className="w-full">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          addFiles(e.dataTransfer.files);
        }}
        onClick={() => inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") inputRef.current?.click();
        }}
        className={`group relative flex min-h-[240px] cursor-pointer flex-col items-center justify-center rounded-[28px] border transition-all duration-300 ${
          dragging
            ? "border-gold bg-gold/5 scale-[1.01]"
            : "border-black/10 bg-black/[0.02] hover:border-black/20 hover:bg-black/[0.035] dark:border-white/12 dark:bg-white/[0.03] dark:hover:border-white/20 dark:hover:bg-white/[0.05]"
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => addFiles(e.target.files)}
        />
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gold/15 text-gold transition-transform duration-300 group-hover:scale-110">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path
              d="M12 16V4M12 4l-4.5 4.5M12 4l4.5 4.5"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <p className="mt-4 font-display text-[17px] font-medium text-ink dark:text-white">
          Drop photos here, or click to choose
        </p>
        <p className="mt-1 text-[13px] text-smoke">
          JPG, PNG, HEIC, WEBP · up to 15MB each
        </p>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1.5 block text-[12px] font-medium uppercase tracking-wide text-smoke">
            Your name (optional)
          </span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Who's adding these?"
            maxLength={60}
            className="w-full rounded-xl border border-black/10 bg-white/60 px-4 py-3 text-[15px] text-ink outline-none transition-colors placeholder:text-smoke/70 focus:border-gold/60 dark:border-white/12 dark:bg-white/[0.04] dark:text-white"
          />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[12px] font-medium uppercase tracking-wide text-smoke">
            Caption (optional)
          </span>
          <input
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder="What's the memory?"
            maxLength={200}
            className="w-full rounded-xl border border-black/10 bg-white/60 px-4 py-3 text-[15px] text-ink outline-none transition-colors placeholder:text-smoke/70 focus:border-gold/60 dark:border-white/12 dark:bg-white/[0.04] dark:text-white"
          />
        </label>
      </div>

      {items.length > 0 && (
        <div className="mt-8">
          <div className="mb-4 flex items-center justify-between">
            <p className="text-[13px] text-smoke">
              {items.length} photo{items.length > 1 ? "s" : ""} selected
            </p>
            {pendingCount > 0 && (
              <button
                onClick={uploadAll}
                className="rounded-full bg-ink px-5 py-2 text-[13px] font-medium text-white transition-transform active:scale-95 dark:bg-white dark:text-ink"
              >
                Add {pendingCount} to the wall
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
            {items.map((item) => (
              <div
                key={item.key}
                className="group relative aspect-square overflow-hidden rounded-2xl bg-black/5 dark:bg-white/5"
              >
                <Image
                  src={item.preview}
                  alt=""
                  fill
                  unoptimized
                  className="object-cover"
                />
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/0 transition-colors group-hover:bg-black/40">
                  {item.status === "pending" && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        removeItem(item.key);
                      }}
                      className="hidden rounded-full bg-white/90 px-3 py-1 text-[12px] font-medium text-ink group-hover:block"
                    >
                      Remove
                    </button>
                  )}
                  {item.status === "uploading" && (
                    <span className="rounded-full bg-black/60 px-3 py-1 text-[12px] font-medium text-white">
                      Adding…
                    </span>
                  )}
                  {item.status === "done" && (
                    <span className="rounded-full bg-gold px-3 py-1 text-[12px] font-medium text-white">
                      Added ✓
                    </span>
                  )}
                  {item.status === "error" && (
                    <span className="rounded-full bg-red-500/90 px-3 py-1 text-center text-[11px] font-medium text-white">
                      {item.error || "Failed — try again below"}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
