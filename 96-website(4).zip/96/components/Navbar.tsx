"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ThemeToggle } from "./ThemeToggle";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/wall", label: "The Wall" },
];

export function Navbar() {
  const pathname = usePathname();

  return (
    <header className="fixed inset-x-0 top-0 z-50 flex justify-center px-4 pt-4">
      <nav
        className="glass flex w-full max-w-2xl items-center justify-between rounded-full border border-black/5 px-2 py-2 shadow-[0_1px_1px_rgba(0,0,0,0.03),0_8px_30px_rgba(0,0,0,0.06)] dark:border-white/10 dark:shadow-[0_1px_1px_rgba(0,0,0,0.4),0_8px_30px_rgba(0,0,0,0.5)]"
        aria-label="Primary"
      >
        <Link
          href="/"
          className="flex items-center pl-3 pr-2 font-display text-[15px] font-semibold tracking-tighter text-ink dark:text-mist"
        >
          96
        </Link>

        <div className="flex items-center gap-1 rounded-full bg-black/5 p-1 dark:bg-white/5">
          {LINKS.map((link) => {
            const active = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`relative rounded-full px-4 py-1.5 text-[13px] font-medium transition-colors ${
                  active
                    ? "bg-white text-ink shadow-sm dark:bg-white/15 dark:text-white"
                    : "text-smoke hover:text-ink dark:text-white/50 dark:hover:text-white"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </div>

        <div className="pr-1">
          <ThemeToggle />
        </div>
      </nav>
    </header>
  );
}
