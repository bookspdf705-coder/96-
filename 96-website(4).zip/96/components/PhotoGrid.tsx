"use client";

import { useEffect, useState, useCallback } from "react";
import { Lightbox, type Photo } from "./Lightbox";

export function PhotoGrid() {
  const [photos, setPhotos] = useState<Photo[] | null>(null);
  const [active, setActive] = useState<Photo | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/photos", { cache: "no-store" });
      if (!res.ok) throw new Error();
      const data = await res.json();
      setPhotos(data.photos || []);
    } catch {
      setError("The wall couldn't load. Check your connection and try again.");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-32 text-center">
        <p className="text-[15px] text-smoke">{error}</p>
        <button
          onClick={() => {
            setError(null);
            load();
          }}
          className="mt-4 rounded-full bg-ink px-5 py-2 text-[13px] font-medium text-white dark:bg-white dark:text-ink"
        >
          Try again
        </button>
      </div>
    );
  }

  if (photos === null) {
    return (
      <div className="columns-2 gap-3 sm:columns-3 md:columns-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div
            key={i}
            className="mb-3 break-inside-avoid rounded-2xl bg-black/5 dark:bg-white/5"
            style={{ height: 140 + ((i * 47) % 160) }}
          />
        ))}
      </div>
    );
  }

  if (photos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-32 text-center">
        <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-gold/12 text-gold">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <rect
              x="3"
              y="5"
              width="18"
              height="14"
              rx="2.5"
              stroke="currentColor"
              strokeWidth="1.7"
            />
            <circle cx="8.5" cy="10" r="1.6" fill="currentColor" />
            <path
              d="M4 17l5-5 3.5 3.5L16 12l4 4.5"
              stroke="currentColor"
              strokeWidth="1.7"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <p className="font-display text-[20px] font-medium text-ink dark:text-white">
          The wall is empty, for now
        </p>
        <p className="mt-1.5 max-w-xs text-[14px] text-smoke">
          Head to Home and be the first to add a memory.
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="columns-2 gap-3 sm:columns-3 md:columns-4">
        {photos.map((photo, i) => (
          <button
            key={photo.id}
            onClick={() => setActive(photo)}
            className="group relative mb-3 block w-full break-inside-avoid overflow-hidden rounded-2xl bg-black/5 text-left animate-fade-up dark:bg-white/5"
            style={{ animationDelay: `${Math.min(i, 12) * 40}ms` }}
          >
            <img
              src={photo.url}
              alt={photo.caption || "Memory"}
              loading="lazy"
              className="block w-full transition-transform duration-500 group-hover:scale-105"
            />
            {(photo.caption || photo.name) && (
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent p-3 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                {photo.caption && (
                  <p className="line-clamp-2 text-[12.5px] font-medium text-white">
                    {photo.caption}
                  </p>
                )}
                {photo.name && (
                  <p className="mt-0.5 text-[11px] text-white/70">{photo.name}</p>
                )}
              </div>
            )}
          </button>
        ))}
      </div>

      {active && <Lightbox photo={active} onClose={() => setActive(null)} />}
    </>
  );
}
